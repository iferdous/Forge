
scalar-unfused.o:	file format coff-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 41 56                        	pushq	%r14
       2: 56                           	pushq	%rsi
       3: 57                           	pushq	%rdi
       4: 53                           	pushq	%rbx
       5: 48 83 ec 28                  	subq	$0x28, %rsp
       9: 4c 89 c6                     	movq	%r8, %rsi
       c: 48 89 cf                     	movq	%rcx, %rdi
       f: 4c 8b 02                     	movq	(%rdx), %r8
      12: 48 8b 5e 08                  	movq	0x8(%rsi), %rbx
      16: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      20: 48 b9 00 00 00 00 00 00 00 00	movabsq	$0x0, %rcx
      2a: f3 0f 10 19                  	movss	(%rcx), %xmm3
      2e: 48 89 d9                     	movq	%rbx, %rcx
      31: 48 89 fa                     	movq	%rdi, %rdx
      34: ff d0                        	callq	*%rax
      36: 4c 8b 76 10                  	movq	0x10(%rsi), %r14
      3a: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      44: 48 b9 00 00 00 00 00 00 00 00	movabsq	$0x0, %rcx
      4e: f3 0f 10 19                  	movss	(%rcx), %xmm3
      52: 4c 89 f1                     	movq	%r14, %rcx
      55: 48 89 fa                     	movq	%rdi, %rdx
      58: 49 89 d8                     	movq	%rbx, %r8
      5b: ff d0                        	callq	*%rax
      5d: 48 8b 0e                     	movq	(%rsi), %rcx
      60: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      6a: 48 89 fa                     	movq	%rdi, %rdx
      6d: 4d 89 f0                     	movq	%r14, %r8
      70: 48 83 c4 28                  	addq	$0x28, %rsp
      74: 5b                           	popq	%rbx
      75: 5f                           	popq	%rdi
      76: 5e                           	popq	%rsi
      77: 41 5e                        	popq	%r14
      79: 48 ff e0                     	jmpq	*%rax
      7c: 0f 1f 40 00                  	nopl	(%rax)

0000000000000080 <forge_add_3>:
      80: 48 85 d2                     	testq	%rdx, %rdx
      83: 74 22                        	je	0xa7 <forge_add_3+0x27>
      85: 31 c0                        	xorl	%eax, %eax
      87: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      90: f3 41 0f 10 04 80            	movss	(%r8,%rax,4), %xmm0
      96: f3 0f 58 c3                  	addss	%xmm3, %xmm0
      9a: f3 0f 11 04 81               	movss	%xmm0, (%rcx,%rax,4)
      9f: 48 ff c0                     	incq	%rax
      a2: 48 39 c2                     	cmpq	%rax, %rdx
      a5: 75 e9                        	jne	0x90 <forge_add_3+0x10>
      a7: c3                           	retq
      a8: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)

00000000000000b0 <forge_multiply_6>:
      b0: 48 85 d2                     	testq	%rdx, %rdx
      b3: 74 22                        	je	0xd7 <forge_multiply_6+0x27>
      b5: 31 c0                        	xorl	%eax, %eax
      b7: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      c0: f3 41 0f 10 04 80            	movss	(%r8,%rax,4), %xmm0
      c6: f3 0f 59 c3                  	mulss	%xmm3, %xmm0
      ca: f3 0f 11 04 81               	movss	%xmm0, (%rcx,%rax,4)
      cf: 48 ff c0                     	incq	%rax
      d2: 48 39 c2                     	cmpq	%rax, %rdx
      d5: 75 e9                        	jne	0xc0 <forge_multiply_6+0x10>
      d7: c3                           	retq
      d8: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)

00000000000000e0 <forge_sqrt_7>:
      e0: 48 85 d2                     	testq	%rdx, %rdx
      e3: 74 22                        	je	0x107 <forge_sqrt_7+0x27>
      e5: 31 c0                        	xorl	%eax, %eax
      e7: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      f0: f3 41 0f 10 04 80            	movss	(%r8,%rax,4), %xmm0
      f6: f3 0f 51 c0                  	sqrtss	%xmm0, %xmm0
      fa: f3 0f 11 04 81               	movss	%xmm0, (%rcx,%rax,4)
      ff: 48 ff c0                     	incq	%rax
     102: 48 39 c2                     	cmpq	%rax, %rdx
     105: 75 e9                        	jne	0xf0 <forge_sqrt_7+0x10>
     107: c3                           	retq
