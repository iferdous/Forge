
scalar-fused.o:	file format coff-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 48 89 c8                     	movq	%rcx, %rax
       7: 4c 8b 0a                     	movq	(%rdx), %r9
       a: 49 8b 08                     	movq	(%r8), %rcx
       d: c7 44 24 20 00 00 40 40      	movl	$0x40400000, 0x20(%rsp) # imm = 0x40400000
      15: 49 ba 00 00 00 00 00 00 00 00	movabsq	$0x0, %r10
      1f: 48 ba 00 00 00 00 00 00 00 00	movabsq	$0x0, %rdx
      29: f3 0f 10 1a                  	movss	(%rdx), %xmm3
      2d: 48 89 c2                     	movq	%rax, %rdx
      30: 4d 89 c8                     	movq	%r9, %r8
      33: 41 ff d2                     	callq	*%r10
      36: 90                           	nop
      37: 48 83 c4 28                  	addq	$0x28, %rsp
      3b: c3                           	retq
      3c: 0f 1f 40 00                  	nopl	(%rax)

0000000000000040 <forge_fused_7>:
      40: 48 85 d2                     	testq	%rdx, %rdx
      43: 74 2a                        	je	0x6f <forge_fused_7+0x2f>
      45: f3 0f 10 44 24 28            	movss	0x28(%rsp), %xmm0
      4b: 31 c0                        	xorl	%eax, %eax
      4d: 0f 1f 00                     	nopl	(%rax)
      50: f3 41 0f 10 0c 80            	movss	(%r8,%rax,4), %xmm1
      56: f3 0f 58 cb                  	addss	%xmm3, %xmm1
      5a: f3 0f 59 c8                  	mulss	%xmm0, %xmm1
      5e: f3 0f 51 c9                  	sqrtss	%xmm1, %xmm1
      62: f3 0f 11 0c 81               	movss	%xmm1, (%rcx,%rax,4)
      67: 48 ff c0                     	incq	%rax
      6a: 48 39 c2                     	cmpq	%rax, %rdx
      6d: 75 e1                        	jne	0x50 <forge_fused_7+0x10>
      6f: c3                           	retq
