; ModuleID = 'forge'
source_filename = "forge"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

define void @forge_kernel(i64 %count, ptr nofree readonly captures(none) %inputs, ptr nofree readonly captures(none) %buffers) local_unnamed_addr {
entry:
  %0 = load ptr, ptr %inputs, align 8
  %1 = getelementptr inbounds nuw i8, ptr %buffers, i64 8
  %2 = load ptr, ptr %1, align 8
  tail call void @forge_add_3(ptr %2, i64 %count, ptr %0, float 2.000000e+00)
  %3 = getelementptr inbounds nuw i8, ptr %buffers, i64 16
  %4 = load ptr, ptr %3, align 8
  tail call void @forge_multiply_6(ptr %4, i64 %count, ptr %2, float 3.000000e+00)
  %5 = load ptr, ptr %buffers, align 8
  tail call void @forge_sqrt_7(ptr %5, i64 %count, ptr %4)
  ret void
}

; Function Attrs: nobuiltin noinline
define internal void @forge_add_3(ptr noalias %output, i64 %count, ptr readonly %operand0, float nofpclass(nan inf zero sub nnorm) %operand1) unnamed_addr #0 {
entry:
  %0 = icmp eq i64 %count, 0
  br i1 %0, label %exit, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %min.iters.check = icmp ult i64 %count, 8
  br i1 %min.iters.check, label %loop.preheader2, label %vector.ph

vector.ph:                                        ; preds = %loop.preheader
  %n.vec = and i64 %count, -8
  %broadcast.splatinsert = insertelement <8 x float> poison, float %operand1, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index1 = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %1 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index1
  %wide.load = load <8 x float>, ptr %1, align 1
  %2 = fadd <8 x float> %broadcast.splat, %wide.load
  %3 = getelementptr inbounds [4 x i8], ptr %output, i64 %index1
  store <8 x float> %2, ptr %3, align 1
  %index.next = add nuw i64 %index1, 8
  %4 = icmp eq i64 %index.next, %n.vec
  br i1 %4, label %middle.block, label %vector.body, !llvm.loop !0

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %count, %n.vec
  br i1 %cmp.n, label %exit, label %loop.preheader2

loop.preheader2:                                  ; preds = %loop.preheader, %middle.block
  %index.ph = phi i64 [ 0, %loop.preheader ], [ %n.vec, %middle.block ]
  br label %loop

loop:                                             ; preds = %loop.preheader2, %loop
  %index = phi i64 [ %next, %loop ], [ %index.ph, %loop.preheader2 ]
  %5 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index
  %6 = load float, ptr %5, align 1
  %sum = fadd float %operand1, %6
  %7 = getelementptr inbounds [4 x i8], ptr %output, i64 %index
  store float %sum, ptr %7, align 1
  %next = add nuw i64 %index, 1
  %8 = icmp eq i64 %next, %count
  br i1 %8, label %exit, label %loop, !llvm.loop !4

exit:                                             ; preds = %loop, %middle.block, %entry
  ret void
}

; Function Attrs: nobuiltin noinline
define internal void @forge_multiply_6(ptr noalias %output, i64 %count, ptr readonly %operand0, float nofpclass(nan inf zero sub nnorm) %operand1) unnamed_addr #0 {
entry:
  %0 = icmp eq i64 %count, 0
  br i1 %0, label %exit, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %min.iters.check = icmp ult i64 %count, 8
  br i1 %min.iters.check, label %loop.preheader2, label %vector.ph

vector.ph:                                        ; preds = %loop.preheader
  %n.vec = and i64 %count, -8
  %broadcast.splatinsert = insertelement <8 x float> poison, float %operand1, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index1 = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %1 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index1
  %wide.load = load <8 x float>, ptr %1, align 1
  %2 = fmul <8 x float> %broadcast.splat, %wide.load
  %3 = getelementptr inbounds [4 x i8], ptr %output, i64 %index1
  store <8 x float> %2, ptr %3, align 1
  %index.next = add nuw i64 %index1, 8
  %4 = icmp eq i64 %index.next, %n.vec
  br i1 %4, label %middle.block, label %vector.body, !llvm.loop !6

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %count, %n.vec
  br i1 %cmp.n, label %exit, label %loop.preheader2

loop.preheader2:                                  ; preds = %loop.preheader, %middle.block
  %index.ph = phi i64 [ 0, %loop.preheader ], [ %n.vec, %middle.block ]
  br label %loop

loop:                                             ; preds = %loop.preheader2, %loop
  %index = phi i64 [ %next, %loop ], [ %index.ph, %loop.preheader2 ]
  %5 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index
  %6 = load float, ptr %5, align 1
  %product = fmul float %operand1, %6
  %7 = getelementptr inbounds [4 x i8], ptr %output, i64 %index
  store float %product, ptr %7, align 1
  %next = add nuw i64 %index, 1
  %8 = icmp eq i64 %next, %count
  br i1 %8, label %exit, label %loop, !llvm.loop !7

exit:                                             ; preds = %loop, %middle.block, %entry
  ret void
}

; Function Attrs: nobuiltin noinline
define internal void @forge_sqrt_7(ptr noalias %output, i64 %count, ptr readonly %operand0) unnamed_addr #0 {
entry:
  %0 = icmp eq i64 %count, 0
  br i1 %0, label %exit, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %min.iters.check = icmp ult i64 %count, 8
  br i1 %min.iters.check, label %loop.preheader2, label %vector.ph

vector.ph:                                        ; preds = %loop.preheader
  %n.vec = and i64 %count, -8
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index1 = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %1 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index1
  %wide.load = load <8 x float>, ptr %1, align 1
  %2 = tail call <8 x float> @llvm.sqrt.v8f32(<8 x float> %wide.load)
  %3 = getelementptr inbounds [4 x i8], ptr %output, i64 %index1
  store <8 x float> %2, ptr %3, align 1
  %index.next = add nuw i64 %index1, 8
  %4 = icmp eq i64 %index.next, %n.vec
  br i1 %4, label %middle.block, label %vector.body, !llvm.loop !8

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %count, %n.vec
  br i1 %cmp.n, label %exit, label %loop.preheader2

loop.preheader2:                                  ; preds = %loop.preheader, %middle.block
  %index.ph = phi i64 [ 0, %loop.preheader ], [ %n.vec, %middle.block ]
  br label %loop

loop:                                             ; preds = %loop.preheader2, %loop
  %index = phi i64 [ %next, %loop ], [ %index.ph, %loop.preheader2 ]
  %5 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index
  %6 = load float, ptr %5, align 1
  %7 = tail call float @llvm.sqrt.f32(float %6)
  %8 = getelementptr inbounds [4 x i8], ptr %output, i64 %index
  store float %7, ptr %8, align 1
  %next = add nuw i64 %index, 1
  %9 = icmp eq i64 %next, %count
  br i1 %9, label %exit, label %loop, !llvm.loop !9

exit:                                             ; preds = %loop, %middle.block, %entry
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #2

attributes #0 = { nobuiltin noinline }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!0 = distinct !{!0, !1, !2, !3}
!1 = !{!"llvm.loop.isvectorized", i32 1}
!2 = !{!"llvm.loop.vectorize.body", i32 1}
!3 = !{!"llvm.loop.unroll.runtime.disable"}
!4 = distinct !{!4, !3, !1, !5}
!5 = !{!"llvm.loop.vectorize.epilogue", i32 1}
!6 = distinct !{!6, !1, !2, !3}
!7 = distinct !{!7, !3, !1, !5}
!8 = distinct !{!8, !1, !2, !3}
!9 = distinct !{!9, !3, !1, !5}
