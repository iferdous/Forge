
avx2-unfused.o:	file format coff-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 41 56                        	pushq	%r14
       2: 56                           	pushq	%rsi
       3: 57                           	pushq	%rdi
       4: 53                           	pushq	%rbx
       5: 48 83 ec 28                  	subq	$0x28, %rsp
       9: 4c 89 c6                     	movq	%r8, %rsi
       c: 48 89 cf                     	movq	%rcx, %rdi
       f: 4c 8b 02                     	movq	(%rdx), %r8
      12: 48 8b 5e 08                  	movq	0x8(%rsi), %rbx
      16: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      20: 48 b9 00 00 00 00 00 00 00 00	movabsq	$0x0, %rcx
      2a: c5 fa 10 19                  	vmovss	(%rcx), %xmm3
      2e: 48 89 d9                     	movq	%rbx, %rcx
      31: 48 89 fa                     	movq	%rdi, %rdx
      34: ff d0                        	callq	*%rax
      36: 4c 8b 76 10                  	movq	0x10(%rsi), %r14
      3a: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      44: 48 b9 00 00 00 00 00 00 00 00	movabsq	$0x0, %rcx
      4e: c5 fa 10 19                  	vmovss	(%rcx), %xmm3
      52: 4c 89 f1                     	movq	%r14, %rcx
      55: 48 89 fa                     	movq	%rdi, %rdx
      58: 49 89 d8                     	movq	%rbx, %r8
      5b: ff d0                        	callq	*%rax
      5d: 48 8b 0e                     	movq	(%rsi), %rcx
      60: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      6a: 48 89 fa                     	movq	%rdi, %rdx
      6d: 4d 89 f0                     	movq	%r14, %r8
      70: 48 83 c4 28                  	addq	$0x28, %rsp
      74: 5b                           	popq	%rbx
      75: 5f                           	popq	%rdi
      76: 5e                           	popq	%rsi
      77: 41 5e                        	popq	%r14
      79: 48 ff e0                     	jmpq	*%rax
      7c: 0f 1f 40 00                  	nopl	(%rax)

0000000000000080 <forge_add_3>:
      80: 48 85 d2                     	testq	%rdx, %rdx
      83: 74 45                        	je	0xca <forge_add_3+0x4a>
      85: 48 83 fa 08                  	cmpq	$0x8, %rdx
      89: 73 04                        	jae	0x8f <forge_add_3+0xf>
      8b: 31 c0                        	xorl	%eax, %eax
      8d: eb 28                        	jmp	0xb7 <forge_add_3+0x37>
      8f: 48 89 d0                     	movq	%rdx, %rax
      92: 48 83 e0 f8                  	andq	$-0x8, %rax
      96: c4 e2 7d 18 c3               	vbroadcastss	%xmm3, %ymm0
      9b: 45 31 c9                     	xorl	%r9d, %r9d
      9e: 66 90                        	nop
      a0: c4 81 7c 58 0c 88            	vaddps	(%r8,%r9,4), %ymm0, %ymm1
      a6: c4 a1 7c 11 0c 89            	vmovups	%ymm1, (%rcx,%r9,4)
      ac: 49 83 c1 08                  	addq	$0x8, %r9
      b0: 4c 39 c8                     	cmpq	%r9, %rax
      b3: 75 eb                        	jne	0xa0 <forge_add_3+0x20>
      b5: eb 0e                        	jmp	0xc5 <forge_add_3+0x45>
      b7: c4 c1 62 58 04 80            	vaddss	(%r8,%rax,4), %xmm3, %xmm0
      bd: c5 fa 11 04 81               	vmovss	%xmm0, (%rcx,%rax,4)
      c2: 48 ff c0                     	incq	%rax
      c5: 48 39 c2                     	cmpq	%rax, %rdx
      c8: 75 ed                        	jne	0xb7 <forge_add_3+0x37>
      ca: c5 f8 77                     	vzeroupper
      cd: c3                           	retq
      ce: 66 90                        	nop

00000000000000d0 <forge_multiply_6>:
      d0: 48 85 d2                     	testq	%rdx, %rdx
      d3: 74 45                        	je	0x11a <forge_multiply_6+0x4a>
      d5: 48 83 fa 08                  	cmpq	$0x8, %rdx
      d9: 73 04                        	jae	0xdf <forge_multiply_6+0xf>
      db: 31 c0                        	xorl	%eax, %eax
      dd: eb 28                        	jmp	0x107 <forge_multiply_6+0x37>
      df: 48 89 d0                     	movq	%rdx, %rax
      e2: 48 83 e0 f8                  	andq	$-0x8, %rax
      e6: c4 e2 7d 18 c3               	vbroadcastss	%xmm3, %ymm0
      eb: 45 31 c9                     	xorl	%r9d, %r9d
      ee: 66 90                        	nop
      f0: c4 81 7c 59 0c 88            	vmulps	(%r8,%r9,4), %ymm0, %ymm1
      f6: c4 a1 7c 11 0c 89            	vmovups	%ymm1, (%rcx,%r9,4)
      fc: 49 83 c1 08                  	addq	$0x8, %r9
     100: 4c 39 c8                     	cmpq	%r9, %rax
     103: 75 eb                        	jne	0xf0 <forge_multiply_6+0x20>
     105: eb 0e                        	jmp	0x115 <forge_multiply_6+0x45>
     107: c4 c1 62 59 04 80            	vmulss	(%r8,%rax,4), %xmm3, %xmm0
     10d: c5 fa 11 04 81               	vmovss	%xmm0, (%rcx,%rax,4)
     112: 48 ff c0                     	incq	%rax
     115: 48 39 c2                     	cmpq	%rax, %rdx
     118: 75 ed                        	jne	0x107 <forge_multiply_6+0x37>
     11a: c5 f8 77                     	vzeroupper
     11d: c3                           	retq
     11e: 66 90                        	nop

0000000000000120 <forge_sqrt_7>:
     120: 48 85 d2                     	testq	%rdx, %rdx
     123: 74 49                        	je	0x16e <forge_sqrt_7+0x4e>
     125: 48 83 fa 08                  	cmpq	$0x8, %rdx
     129: 73 04                        	jae	0x12f <forge_sqrt_7+0xf>
     12b: 31 c0                        	xorl	%eax, %eax
     12d: eb 28                        	jmp	0x157 <forge_sqrt_7+0x37>
     12f: 48 89 d0                     	movq	%rdx, %rax
     132: 48 83 e0 f8                  	andq	$-0x8, %rax
     136: 45 31 c9                     	xorl	%r9d, %r9d
     139: 0f 1f 80 00 00 00 00         	nopl	(%rax)
     140: c4 81 7c 51 04 88            	vsqrtps	(%r8,%r9,4), %ymm0
     146: c4 a1 7c 11 04 89            	vmovups	%ymm0, (%rcx,%r9,4)
     14c: 49 83 c1 08                  	addq	$0x8, %r9
     150: 4c 39 c8                     	cmpq	%r9, %rax
     153: 75 eb                        	jne	0x140 <forge_sqrt_7+0x20>
     155: eb 12                        	jmp	0x169 <forge_sqrt_7+0x49>
     157: c4 c1 7a 10 04 80            	vmovss	(%r8,%rax,4), %xmm0
     15d: c5 fa 51 c0                  	vsqrtss	%xmm0, %xmm0, %xmm0
     161: c5 fa 11 04 81               	vmovss	%xmm0, (%rcx,%rax,4)
     166: 48 ff c0                     	incq	%rax
     169: 48 39 c2                     	cmpq	%rax, %rdx
     16c: 75 e9                        	jne	0x157 <forge_sqrt_7+0x37>
     16e: c5 f8 77                     	vzeroupper
     171: c3                           	retq
