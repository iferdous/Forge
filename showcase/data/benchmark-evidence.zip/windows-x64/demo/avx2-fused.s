
avx2-fused.o:	file format coff-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 48 89 c8                     	movq	%rcx, %rax
       7: 4c 8b 0a                     	movq	(%rdx), %r9
       a: 49 8b 08                     	movq	(%r8), %rcx
       d: c7 44 24 20 00 00 40 40      	movl	$0x40400000, 0x20(%rsp) # imm = 0x40400000
      15: 49 ba 00 00 00 00 00 00 00 00	movabsq	$0x0, %r10
      1f: 48 ba 00 00 00 00 00 00 00 00	movabsq	$0x0, %rdx
      29: c5 fa 10 1a                  	vmovss	(%rdx), %xmm3
      2d: 48 89 c2                     	movq	%rax, %rdx
      30: 4d 89 c8                     	movq	%r9, %r8
      33: 41 ff d2                     	callq	*%r10
      36: 90                           	nop
      37: 48 83 c4 28                  	addq	$0x28, %rsp
      3b: c3                           	retq
      3c: 0f 1f 40 00                  	nopl	(%rax)

0000000000000040 <forge_fused_7>:
      40: 48 85 d2                     	testq	%rdx, %rdx
      43: 74 65                        	je	0xaa <forge_fused_7+0x6a>
      45: c5 fa 10 44 24 28            	vmovss	0x28(%rsp), %xmm0
      4b: 48 83 fa 08                  	cmpq	$0x8, %rdx
      4f: 73 04                        	jae	0x55 <forge_fused_7+0x15>
      51: 31 c0                        	xorl	%eax, %eax
      53: eb 3a                        	jmp	0x8f <forge_fused_7+0x4f>
      55: 48 89 d0                     	movq	%rdx, %rax
      58: 48 83 e0 f8                  	andq	$-0x8, %rax
      5c: c4 e2 7d 18 cb               	vbroadcastss	%xmm3, %ymm1
      61: c4 e2 7d 18 d0               	vbroadcastss	%xmm0, %ymm2
      66: 45 31 c9                     	xorl	%r9d, %r9d
      69: 0f 1f 80 00 00 00 00         	nopl	(%rax)
      70: c4 81 74 58 24 88            	vaddps	(%r8,%r9,4), %ymm1, %ymm4
      76: c5 ec 59 e4                  	vmulps	%ymm4, %ymm2, %ymm4
      7a: c5 fc 51 e4                  	vsqrtps	%ymm4, %ymm4
      7e: c4 a1 7c 11 24 89            	vmovups	%ymm4, (%rcx,%r9,4)
      84: 49 83 c1 08                  	addq	$0x8, %r9
      88: 4c 39 c8                     	cmpq	%r9, %rax
      8b: 75 e3                        	jne	0x70 <forge_fused_7+0x30>
      8d: eb 16                        	jmp	0xa5 <forge_fused_7+0x65>
      8f: c4 c1 62 58 0c 80            	vaddss	(%r8,%rax,4), %xmm3, %xmm1
      95: c5 fa 59 c9                  	vmulss	%xmm1, %xmm0, %xmm1
      99: c5 f2 51 c9                  	vsqrtss	%xmm1, %xmm1, %xmm1
      9d: c5 fa 11 0c 81               	vmovss	%xmm1, (%rcx,%rax,4)
      a2: 48 ff c0                     	incq	%rax
      a5: 48 39 c2                     	cmpq	%rax, %rdx
      a8: 75 e5                        	jne	0x8f <forge_fused_7+0x4f>
      aa: c5 f8 77                     	vzeroupper
      ad: c3                           	retq
