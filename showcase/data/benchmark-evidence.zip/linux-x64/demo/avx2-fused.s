
avx2-fused.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 48 89 f8                     	movq	%rdi, %rax
       3: 48 8b 0e                     	movq	(%rsi), %rcx
       6: 48 8b 3a                     	movq	(%rdx), %rdi
       9: c5 fa 10 05 00 00 00 00      	vmovss	(%rip), %xmm0           # 0x11 <forge_kernel+0x11>
      11: c5 fa 10 0d 00 00 00 00      	vmovss	(%rip), %xmm1           # 0x19 <forge_kernel+0x19>
      19: 48 89 c6                     	movq	%rax, %rsi
      1c: 48 89 ca                     	movq	%rcx, %rdx
      1f: eb 0f                        	jmp	0x30 <forge_fused_7>
      21: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)

0000000000000030 <forge_fused_7>:
      30: 48 85 f6                     	testq	%rsi, %rsi
      33: 74 62                        	je	0x97 <forge_fused_7+0x67>
      35: 48 83 fe 08                  	cmpq	$0x8, %rsi
      39: 73 04                        	jae	0x3f <forge_fused_7+0xf>
      3b: 31 c0                        	xorl	%eax, %eax
      3d: eb 3e                        	jmp	0x7d <forge_fused_7+0x4d>
      3f: 48 89 f0                     	movq	%rsi, %rax
      42: 48 83 e0 f8                  	andq	$-0x8, %rax
      46: c4 e2 7d 18 d0               	vbroadcastss	%xmm0, %ymm2
      4b: c4 e2 7d 18 d9               	vbroadcastss	%xmm1, %ymm3
      50: 31 c9                        	xorl	%ecx, %ecx
      52: 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	nopw	%cs:(%rax,%rax)
      60: c5 ec 58 24 8a               	vaddps	(%rdx,%rcx,4), %ymm2, %ymm4
      65: c5 e4 59 e4                  	vmulps	%ymm4, %ymm3, %ymm4
      69: c5 fc 51 e4                  	vsqrtps	%ymm4, %ymm4
      6d: c5 fc 11 24 8f               	vmovups	%ymm4, (%rdi,%rcx,4)
      72: 48 83 c1 08                  	addq	$0x8, %rcx
      76: 48 39 c8                     	cmpq	%rcx, %rax
      79: 75 e5                        	jne	0x60 <forge_fused_7+0x30>
      7b: eb 15                        	jmp	0x92 <forge_fused_7+0x62>
      7d: c5 fa 58 14 82               	vaddss	(%rdx,%rax,4), %xmm0, %xmm2
      82: c5 f2 59 d2                  	vmulss	%xmm2, %xmm1, %xmm2
      86: c5 ea 51 d2                  	vsqrtss	%xmm2, %xmm2, %xmm2
      8a: c5 fa 11 14 87               	vmovss	%xmm2, (%rdi,%rax,4)
      8f: 48 ff c0                     	incq	%rax
      92: 48 39 c6                     	cmpq	%rax, %rsi
      95: 75 e6                        	jne	0x7d <forge_fused_7+0x4d>
      97: c5 f8 77                     	vzeroupper
      9a: c3                           	retq
