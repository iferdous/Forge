; ModuleID = 'forge'
source_filename = "forge"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

define void @forge_kernel(i64 %count, ptr nofree readonly captures(none) %inputs, ptr nofree readonly captures(none) %buffers) local_unnamed_addr {
entry:
  %0 = load ptr, ptr %inputs, align 8
  %1 = load ptr, ptr %buffers, align 8
  tail call void @forge_fused_7(ptr %1, i64 %count, ptr %0, float 2.000000e+00, float 3.000000e+00)
  ret void
}

; Function Attrs: nobuiltin noinline
define internal void @forge_fused_7(ptr noalias %output, i64 %count, ptr readonly %operand0, float nofpclass(nan inf zero sub nnorm) %operand1, float nofpclass(nan inf zero sub nnorm) %operand2) unnamed_addr #0 {
entry:
  %0 = icmp eq i64 %count, 0
  br i1 %0, label %exit, label %loop

loop:                                             ; preds = %entry, %loop
  %index = phi i64 [ %next, %loop ], [ 0, %entry ]
  %1 = getelementptr inbounds [4 x i8], ptr %operand0, i64 %index
  %2 = load float, ptr %1, align 1
  %sum = fadd float %operand1, %2
  %product = fmul float %operand2, %sum
  %3 = tail call float @llvm.sqrt.f32(float %product)
  %4 = getelementptr inbounds [4 x i8], ptr %output, i64 %index
  store float %3, ptr %4, align 1
  %next = add nuw i64 %index, 1
  %5 = icmp eq i64 %next, %count
  br i1 %5, label %exit, label %loop

exit:                                             ; preds = %loop, %entry
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #1

attributes #0 = { nobuiltin noinline }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
