
scalar-fused.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 48 89 f8                     	movq	%rdi, %rax
       3: 48 8b 0e                     	movq	(%rsi), %rcx
       6: 48 8b 3a                     	movq	(%rdx), %rdi
       9: f3 0f 10 05 00 00 00 00      	movss	(%rip), %xmm0           # 0x11 <forge_kernel+0x11>
      11: f3 0f 10 0d 00 00 00 00      	movss	(%rip), %xmm1           # 0x19 <forge_kernel+0x19>
      19: 48 89 c6                     	movq	%rax, %rsi
      1c: 48 89 ca                     	movq	%rcx, %rdx
      1f: eb 0f                        	jmp	0x30 <forge_fused_7>
      21: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)

0000000000000030 <forge_fused_7>:
      30: 48 85 f6                     	testq	%rsi, %rsi
      33: 74 29                        	je	0x5e <forge_fused_7+0x2e>
      35: 31 c0                        	xorl	%eax, %eax
      37: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      40: f3 0f 10 14 82               	movss	(%rdx,%rax,4), %xmm2
      45: f3 0f 58 d0                  	addss	%xmm0, %xmm2
      49: f3 0f 59 d1                  	mulss	%xmm1, %xmm2
      4d: f3 0f 51 d2                  	sqrtss	%xmm2, %xmm2
      51: f3 0f 11 14 87               	movss	%xmm2, (%rdi,%rax,4)
      56: 48 ff c0                     	incq	%rax
      59: 48 39 c6                     	cmpq	%rax, %rsi
      5c: 75 e2                        	jne	0x40 <forge_fused_7+0x10>
      5e: c3                           	retq
