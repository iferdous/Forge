
scalar-unfused.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 41 54                        	pushq	%r12
       6: 53                           	pushq	%rbx
       7: 50                           	pushq	%rax
       8: 48 89 d3                     	movq	%rdx, %rbx
       b: 49 89 fe                     	movq	%rdi, %r14
       e: 48 8b 16                     	movq	(%rsi), %rdx
      11: 4c 8b 7b 08                  	movq	0x8(%rbx), %r15
      15: f3 0f 10 05 00 00 00 00      	movss	(%rip), %xmm0           # 0x1d <forge_kernel+0x1d>
      1d: 4c 89 ff                     	movq	%r15, %rdi
      20: 4c 89 f6                     	movq	%r14, %rsi
      23: e8 38 00 00 00               	callq	0x60 <forge_add_3>
      28: 4c 8b 63 10                  	movq	0x10(%rbx), %r12
      2c: f3 0f 10 05 00 00 00 00      	movss	(%rip), %xmm0           # 0x34 <forge_kernel+0x34>
      34: 4c 89 e7                     	movq	%r12, %rdi
      37: 4c 89 f6                     	movq	%r14, %rsi
      3a: 4c 89 fa                     	movq	%r15, %rdx
      3d: e8 4e 00 00 00               	callq	0x90 <forge_multiply_6>
      42: 48 8b 3b                     	movq	(%rbx), %rdi
      45: 4c 89 f6                     	movq	%r14, %rsi
      48: 4c 89 e2                     	movq	%r12, %rdx
      4b: 48 83 c4 08                  	addq	$0x8, %rsp
      4f: 5b                           	popq	%rbx
      50: 41 5c                        	popq	%r12
      52: 41 5e                        	popq	%r14
      54: 41 5f                        	popq	%r15
      56: eb 68                        	jmp	0xc0 <forge_sqrt_7>
      58: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)

0000000000000060 <forge_add_3>:
      60: 48 85 f6                     	testq	%rsi, %rsi
      63: 74 21                        	je	0x86 <forge_add_3+0x26>
      65: 31 c0                        	xorl	%eax, %eax
      67: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      70: f3 0f 10 0c 82               	movss	(%rdx,%rax,4), %xmm1
      75: f3 0f 58 c8                  	addss	%xmm0, %xmm1
      79: f3 0f 11 0c 87               	movss	%xmm1, (%rdi,%rax,4)
      7e: 48 ff c0                     	incq	%rax
      81: 48 39 c6                     	cmpq	%rax, %rsi
      84: 75 ea                        	jne	0x70 <forge_add_3+0x10>
      86: c3                           	retq
      87: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)

0000000000000090 <forge_multiply_6>:
      90: 48 85 f6                     	testq	%rsi, %rsi
      93: 74 21                        	je	0xb6 <forge_multiply_6+0x26>
      95: 31 c0                        	xorl	%eax, %eax
      97: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      a0: f3 0f 10 0c 82               	movss	(%rdx,%rax,4), %xmm1
      a5: f3 0f 59 c8                  	mulss	%xmm0, %xmm1
      a9: f3 0f 11 0c 87               	movss	%xmm1, (%rdi,%rax,4)
      ae: 48 ff c0                     	incq	%rax
      b1: 48 39 c6                     	cmpq	%rax, %rsi
      b4: 75 ea                        	jne	0xa0 <forge_multiply_6+0x10>
      b6: c3                           	retq
      b7: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)

00000000000000c0 <forge_sqrt_7>:
      c0: 48 85 f6                     	testq	%rsi, %rsi
      c3: 74 21                        	je	0xe6 <forge_sqrt_7+0x26>
      c5: 31 c0                        	xorl	%eax, %eax
      c7: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      d0: f3 0f 10 04 82               	movss	(%rdx,%rax,4), %xmm0
      d5: f3 0f 51 c0                  	sqrtss	%xmm0, %xmm0
      d9: f3 0f 11 04 87               	movss	%xmm0, (%rdi,%rax,4)
      de: 48 ff c0                     	incq	%rax
      e1: 48 39 c6                     	cmpq	%rax, %rsi
      e4: 75 ea                        	jne	0xd0 <forge_sqrt_7+0x10>
      e6: c3                           	retq
