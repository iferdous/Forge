
avx2-unfused.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <forge_kernel>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 41 54                        	pushq	%r12
       6: 53                           	pushq	%rbx
       7: 50                           	pushq	%rax
       8: 48 89 d3                     	movq	%rdx, %rbx
       b: 49 89 fe                     	movq	%rdi, %r14
       e: 48 8b 16                     	movq	(%rsi), %rdx
      11: 4c 8b 7b 08                  	movq	0x8(%rbx), %r15
      15: c5 fa 10 05 00 00 00 00      	vmovss	(%rip), %xmm0           # 0x1d <forge_kernel+0x1d>
      1d: 4c 89 ff                     	movq	%r15, %rdi
      20: 4c 89 f6                     	movq	%r14, %rsi
      23: e8 38 00 00 00               	callq	0x60 <forge_add_3>
      28: 4c 8b 63 10                  	movq	0x10(%rbx), %r12
      2c: c5 fa 10 05 00 00 00 00      	vmovss	(%rip), %xmm0           # 0x34 <forge_kernel+0x34>
      34: 4c 89 e7                     	movq	%r12, %rdi
      37: 4c 89 f6                     	movq	%r14, %rsi
      3a: 4c 89 fa                     	movq	%r15, %rdx
      3d: e8 6e 00 00 00               	callq	0xb0 <forge_multiply_6>
      42: 48 8b 3b                     	movq	(%rbx), %rdi
      45: 4c 89 f6                     	movq	%r14, %rsi
      48: 4c 89 e2                     	movq	%r12, %rdx
      4b: 48 83 c4 08                  	addq	$0x8, %rsp
      4f: 5b                           	popq	%rbx
      50: 41 5c                        	popq	%r12
      52: 41 5e                        	popq	%r14
      54: 41 5f                        	popq	%r15
      56: e9 a5 00 00 00               	jmp	0x100 <forge_sqrt_7>
      5b: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000060 <forge_add_3>:
      60: 48 85 f6                     	testq	%rsi, %rsi
      63: 74 42                        	je	0xa7 <forge_add_3+0x47>
      65: 48 83 fe 08                  	cmpq	$0x8, %rsi
      69: 73 04                        	jae	0x6f <forge_add_3+0xf>
      6b: 31 c0                        	xorl	%eax, %eax
      6d: eb 26                        	jmp	0x95 <forge_add_3+0x35>
      6f: 48 89 f0                     	movq	%rsi, %rax
      72: 48 83 e0 f8                  	andq	$-0x8, %rax
      76: c4 e2 7d 18 c8               	vbroadcastss	%xmm0, %ymm1
      7b: 31 c9                        	xorl	%ecx, %ecx
      7d: 0f 1f 00                     	nopl	(%rax)
      80: c5 f4 58 14 8a               	vaddps	(%rdx,%rcx,4), %ymm1, %ymm2
      85: c5 fc 11 14 8f               	vmovups	%ymm2, (%rdi,%rcx,4)
      8a: 48 83 c1 08                  	addq	$0x8, %rcx
      8e: 48 39 c8                     	cmpq	%rcx, %rax
      91: 75 ed                        	jne	0x80 <forge_add_3+0x20>
      93: eb 0d                        	jmp	0xa2 <forge_add_3+0x42>
      95: c5 fa 58 0c 82               	vaddss	(%rdx,%rax,4), %xmm0, %xmm1
      9a: c5 fa 11 0c 87               	vmovss	%xmm1, (%rdi,%rax,4)
      9f: 48 ff c0                     	incq	%rax
      a2: 48 39 c6                     	cmpq	%rax, %rsi
      a5: 75 ee                        	jne	0x95 <forge_add_3+0x35>
      a7: c5 f8 77                     	vzeroupper
      aa: c3                           	retq
      ab: 0f 1f 44 00 00               	nopl	(%rax,%rax)

00000000000000b0 <forge_multiply_6>:
      b0: 48 85 f6                     	testq	%rsi, %rsi
      b3: 74 42                        	je	0xf7 <forge_multiply_6+0x47>
      b5: 48 83 fe 08                  	cmpq	$0x8, %rsi
      b9: 73 04                        	jae	0xbf <forge_multiply_6+0xf>
      bb: 31 c0                        	xorl	%eax, %eax
      bd: eb 26                        	jmp	0xe5 <forge_multiply_6+0x35>
      bf: 48 89 f0                     	movq	%rsi, %rax
      c2: 48 83 e0 f8                  	andq	$-0x8, %rax
      c6: c4 e2 7d 18 c8               	vbroadcastss	%xmm0, %ymm1
      cb: 31 c9                        	xorl	%ecx, %ecx
      cd: 0f 1f 00                     	nopl	(%rax)
      d0: c5 f4 59 14 8a               	vmulps	(%rdx,%rcx,4), %ymm1, %ymm2
      d5: c5 fc 11 14 8f               	vmovups	%ymm2, (%rdi,%rcx,4)
      da: 48 83 c1 08                  	addq	$0x8, %rcx
      de: 48 39 c8                     	cmpq	%rcx, %rax
      e1: 75 ed                        	jne	0xd0 <forge_multiply_6+0x20>
      e3: eb 0d                        	jmp	0xf2 <forge_multiply_6+0x42>
      e5: c5 fa 59 0c 82               	vmulss	(%rdx,%rax,4), %xmm0, %xmm1
      ea: c5 fa 11 0c 87               	vmovss	%xmm1, (%rdi,%rax,4)
      ef: 48 ff c0                     	incq	%rax
      f2: 48 39 c6                     	cmpq	%rax, %rsi
      f5: 75 ee                        	jne	0xe5 <forge_multiply_6+0x35>
      f7: c5 f8 77                     	vzeroupper
      fa: c3                           	retq
      fb: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000100 <forge_sqrt_7>:
     100: 48 85 f6                     	testq	%rsi, %rsi
     103: 74 46                        	je	0x14b <forge_sqrt_7+0x4b>
     105: 48 83 fe 08                  	cmpq	$0x8, %rsi
     109: 73 04                        	jae	0x10f <forge_sqrt_7+0xf>
     10b: 31 c0                        	xorl	%eax, %eax
     10d: eb 26                        	jmp	0x135 <forge_sqrt_7+0x35>
     10f: 48 89 f0                     	movq	%rsi, %rax
     112: 48 83 e0 f8                  	andq	$-0x8, %rax
     116: 31 c9                        	xorl	%ecx, %ecx
     118: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
     120: c5 fc 51 04 8a               	vsqrtps	(%rdx,%rcx,4), %ymm0
     125: c5 fc 11 04 8f               	vmovups	%ymm0, (%rdi,%rcx,4)
     12a: 48 83 c1 08                  	addq	$0x8, %rcx
     12e: 48 39 c8                     	cmpq	%rcx, %rax
     131: 75 ed                        	jne	0x120 <forge_sqrt_7+0x20>
     133: eb 11                        	jmp	0x146 <forge_sqrt_7+0x46>
     135: c5 fa 10 04 82               	vmovss	(%rdx,%rax,4), %xmm0
     13a: c5 fa 51 c0                  	vsqrtss	%xmm0, %xmm0, %xmm0
     13e: c5 fa 11 04 87               	vmovss	%xmm0, (%rdi,%rax,4)
     143: 48 ff c0                     	incq	%rax
     146: 48 39 c6                     	cmpq	%rax, %rsi
     149: 75 ea                        	jne	0x135 <forge_sqrt_7+0x35>
     14b: c5 f8 77                     	vzeroupper
     14e: c3                           	retq
